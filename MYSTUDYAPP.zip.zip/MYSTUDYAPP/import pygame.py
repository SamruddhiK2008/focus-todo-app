import pygame

pygame.mixer.init()
pygame.mixer.music.load("motivation.mp3")
pygame.mixer.music.play()

input("Press Enter to stop...")
pygame.mixer.music.stop()