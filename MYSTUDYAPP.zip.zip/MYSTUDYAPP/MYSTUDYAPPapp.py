import tkinter as tk
from tkinter import messagebox
import pygame
import time
import threading

# Initialize pygame mixer
pygame.mixer.init()

# Function to play motivation audio
def play_motivation():
    try:
        pygame.mixer.music.load("motivation.mp3")
        pygame.mixer.music.play()
    except:
        messagebox.showerror("Error", "motivation.mp3 file not found!")

# Countdown timer function
def start_timer():
    try:
        total_time = int(entry.get()) * 60  # Minutes to seconds
    except ValueError:
        messagebox.showerror("Invalid Input", "Enter time in minutes (numbers only).")
        return

    btn_start.config(state=tk.DISABLED)
    play_motivation()
    
    def countdown():
        while total_time > 0:
            mins, secs = divmod(total_time, 60)
            timer_display.config(text=f"{mins:02d}:{secs:02d}")
            time.sleep(1)
            nonlocal total_time
            total_time -= 1

        timer_display.config(text="00:00")
        messagebox.showinfo("Time's up!", "Take a short break!")
        btn_start.config(state=tk.NORMAL)

    threading.Thread(target=countdown).start()

# GUI setup
root = tk.Tk()
root.title("Study Timer")
root.geometry("300x200")

label = tk.Label(root, text="Enter time (in minutes):")
label.pack(pady=10)

entry = tk.Entry(root)
entry.pack()

btn_start = tk.Button(root, text="Start Timer", command=start_timer)
btn_start.pack(pady=10)

timer_display = tk.Label(root, text="00:00", font=("Helvetica", 24))
timer_display.pack(pady=10)

root.mainloop()